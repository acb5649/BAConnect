<form id="regUser"  action="login.php" method="post">
	<!-- First Name -->
	<h3 class = "txt">First Name:</h3>
	<input type="text" maxlength = "50" value="" name="firstNameReg" id="firstNameReg" placeholder="Enter First Name" class="tbx"  required> <br>
					
	<!-- Middle Name -->
	<h3 class = "txt">Middle Name:</h3>
	<input type = "text" maxlength = "50" value = "" name = "middleNameReg" id = "middleNameReg" placeholder="Enter Middle Name" class="tbx" required><br>
					
	<!-- Last Name-->
	<h3 class = "txt">Last Name:</h3>
	<input type="text" maxlength = "50" value="" name="lastNameReg" id="lastNameReg" placeholder="Enter Last Name" class="tbx" required><br>
					
	<!-- Email -->
	<h3 class = "txt">Email:</h3> 
	<input type="email" id="emailReg" placeholder="Enter Email" name="emailReg"   class="tbx" required><br>
					
	<!-- Confirm Email -->
	<h3 class = "txt">Confirm Email:</h3>
	<input type="email" id="emailConfirmReg" placeholder="Confirm Email" name="emailConfirmReg"  class="tbx" required><br>
					
	<!--Username -->
	<h3 class = "txt">Username:</h3> 
	<input type = "text" id="usernameReg" name = "usernameReg" maxlength ="50" placeholder="Enter Username" class="tbx" required><br>
					
	<!--Password-->				
	<h3 class = "txt">Password:</h3>
	<input type="password" id="passwordReg" placeholder="Enter Password" name="passwordReg" class="tbx" required><br>
	
	<!-- Confirm Password-->
	<h3 class = "txt">Confirm Password:</h3>
	<input type="password" id="passwordConfirmReg" placeholder="Enter Password" name="passwordConfirmReg" class="tbx" required><br>
	
	<!-- Gender -->
	<h3 class = "txt">Gender:</h3>
	<div id="genderReg" style="margin-top: 1em;">
		<input type="radio" id="male" name="radio" checked= "checked" value="Male"><label for="male">Male</label>
		<input type="radio" id="female" name="radio"><label for="female" value="Female">Female</label>
		<input type="radio" id="transexual" name="radio"><label for="transexual" value="Transexual">Transexual</label>
	</div><br>
	
	<!-- County -->
	<h3 class = "txt">Country:</h3>
	<select id="country" name = "country">
		<?php 
			//populate list
			$list = countryList();
			//using foreach to assign the label to a variable and the value to a variable
			foreach ($list as $pos => $value)
				print '	<option value = "'.$value.'">'.$value.'</option>';
		?>
	</select><br>
	
	<!--Telephone-->
	<h3 class = "txt">Phone Number:</h3>
	<input type="tel" id="tele" placeholder="(317) 444 6954" name="tele" class="tbx" required><br>
	
	<div class="cbox">
		<h3 class = "txt">Status:</h3>
		<h3 class"cbox"><input type="checkbox"   "name = "student" value="1">Student</h3>
		<h3 class"cbox"><input type="checkbox"  name = "Working Professional" value="1">Working Professional</h3>
	</div>
	
	<h3 class = "txt">Education:</h3><br>
	<div>
		<button id="addDeg" name = "addEntry"  type = "button" value = "Add degree" onclick = "addField()">Add Degree</button>
	<div><br>
	<fieldset id="education"></fieldset><br>
					
	<!--
					

					

					Status:
					<br>
					<input type="checkbox" name = "student" value="1">
					student
					<br>
					<input type="checkbox" name = "Working Professional" value="1">
					Working Professional
					<br>
					Education:
					<br>
					Degree:
					<input name = "addEntry" class = "btn" type = "button" value = "Add degree" onclick = "addField()">
					<fieldset id="education"></fieldset>
					<br>-->
					
					<!-- Submit -->
		<br><button name="enter" type="submit" class="btn" id="submit">Register</button>
	</form>
	