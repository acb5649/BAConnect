<!--DOCTYPE html-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Admin Control Panel</title>
		<!-- Link to css for theme colors -->
		<link href="theme/jquery-ui.css" rel="stylesheet"> 
		<link href="theme/jquery-ui.structure.css" rel="stylesheet"> 
		<link href="theme/jquery-ui.theme.css" rel="stylesheet"> 
	
		<!-- Website base CSS -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body id="body">
		<div id="command">
			<h3>Match Users</h3>
			<div>
				<form id="matchUser"  action="ccenter.php" method="post">
					<?php
						// CONNECT to DB & read in MYSQL DATA
						
						
						/*******Associative Arrays use a name/value pair to access a value **********/

						//assign values directly
						$mentor["first"] = "Sam";
						$mentor["second"] = "Edna";			
						$mentor["third"] = "Mark";
						$mentor["fourth"] = "Clayton";
						$mentor["fifth"] = "Junior";
				
						//assign values directly
						$mentee["first"] = "Steve";
						$mentee["second"] = "Karla";			
						$mentee["third"] = "Sarah";
						$mentee["fourth"] = "Jud";
						$mentee["fifth"] = "Marven";
					?>
					<select id ="mentor" name = "mentor">
						<?php
						//using foreach to assign the label to a variable and the value to a variable
		
							foreach ($mentor as $pos => $value)
								print '	<option value = "'.$pos.'">'.$value.'</option>';
						?>
					</select>
					<select id="mentee" name = "mentee">
						<?php
							//using foreach to assign the label to a variable and the value to a variable
		
							foreach ($mentee as $pos => $value)
								print '	<option value = "'.$pos.'">'.$value.'</option>';
						?>
					</select>
					<!-- Submit -->
					<button type="submit" class="btn" id="match">Match</button>
				</form><br>
			</div>
			<h3>Edit Account(s)</h3>
			<div>
			</div>
			<h3>Upgrade Account(s)</h3>
			<div>
			</div>
			<h3>Search User Database</h3>
			<div>
			</div>
		</div>
		
		<!-- link to jQuery-->
		<script src="js/jquery-3.3.1.js"></script>
		
		<!-- Link to jQuery Library -->
		<script src="theme/external/jquery/jquery.js"></script>
		
		<!-- jQuery UI functionality -->
		<script type="text/javascript" src="theme/jquery-ui.js"></script>
		
		<!-- Link to jQuery Validator -->
		<script type="text/javascript" src="validation/dist/jquery.validate.js"></script>
		
		<!--Script for website-->
		<script type="text/javascript" src="js/cpanel.js"></script>
		
	<body>
</html>