<form id = "recoverText" action="recovery.php" method="post">
	<!--grab recovery telephone-->
	<label class = "txt">Phone Number:</label>
	<input type="tel" id="tele" placeholder="(317) 444 6954" name="tele" class="tbx" required><br>
		
	<!-- Send confirm code -->
	<button type="submit" class="btn" id="recoverT">Send</button>
			
</form>