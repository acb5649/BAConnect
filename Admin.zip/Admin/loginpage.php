<form id="loginUser"  action="login.php" method="post">
	<!--Username-->
	<h3 class = "txt">Username:</h3>
	<input type="text" id="logUser" placeholder="Enter Username" name="logUser" class="tbx" required autofocus><br><br>
				
	<!--Password-->
	<h3 class = "txt">Password:</h3>
	<input type="password" id="logPassword" placeholder="Enter Password" name="logPassword" class="tbx" required><br><br>
					
	<!-- User Login -->
	<button name = "connect" type="submit" class="btn" id="connect">Login<?php if (isset($_POST['connect'])){Header ("Location:ccenter.php?");} ?></button>
	
	<!-- Forgot Password -->
	<a href="recovery.php"><h3 class="link">Forgot Password?</h3></a>
				
</form>
