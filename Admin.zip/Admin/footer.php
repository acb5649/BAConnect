<p class = "copyr">
	Copyright &copy; 2018. BACI all rights reserved
</p>