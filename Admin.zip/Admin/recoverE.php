<form id = "recoverEmail" action="recovery.php" method="post">
	<!-- grab recovery email-->
	<label class = "txt">Email:</label>
	<input type="email" id="emailReg" placeholder="Enter Email" name="emailReg"   class="tbx" required><br>
			
			
	<!-- Send Recovery Link -->
	<button type="submit" class="btn" id="recoverE">Send</button>
</form>