$(document).ready(function() {
	//admin commands
	$("#command").accordion();
	//select a mentor
	$("#mentor").selectmenu();
	//select a mentee
	$("#mentee").selectmenu();
	//sumbit a match manually
	$( "#match" ).button();		

});