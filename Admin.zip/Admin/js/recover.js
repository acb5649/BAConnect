$(document).ready(function() {
	$("#recover").accordion();
	$("#recoverE").button();
	$("#recoverT").button();
});