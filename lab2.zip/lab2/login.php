<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- 
Jonathan Young
login.php
-->
<html lang="EN" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title> Login</title>
	<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="css/mySTYLE.css">
	<style type = "text/css">
  		h1, h2, fieldset {
			color: #4CAF50;
    		text-align: center;
  		}
		.btn {
			border-radius: 4px;
			background-color: white; 
			color: #4CAF50; 
			border: 2px solid #4CAF50;
			font-size: 16px;
		}
		.btn:hover {
			background-color: #4CAF50;
			color: white;
		}
	</style>

	</head>

	<body>

		<?php
			$em = "";
			$pass = "";
			$msg = "";
			
		?>
		<h1 style="font-family: 'Anton' , sans-serif;">Login</h1>
		<?php
				print $msg;
				$msg = "";
			?>
		<fieldset style = "color: #4CAF50">
			<br/>
			<b>Email:</b><br/>	 
			<input type="email" maxlength = "50" value="<?php print $em; ?>" name="email" id="email" required  /><br />
			<br/>
			<b>Password:</b><br/>
			<input type="password" maxlength = "50" value="<?php print $pass; ?>" name="password" id="password" required  /><br/>
			
			<input name="enter" class="btn" type="submit" value="Login" />
		</fieldset>
	
					</form>



	</body>
</html>