<!DOCTYPE html>
<html lang="en">
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Lab 1</title>
		
		<!-- Link to css for theme colors -->
		<link href="theme/jquery-ui.css" rel="stylesheet"> 
		<link href="theme/jquery-ui.structure.css" rel="stylesheet"> 
		<link href="theme/jquery-ui.theme.css" rel="stylesheet"> 
		
		<!-- Link to css for internal script -->
		<link href="css/Form.css" rel="stylesheet" type="text/css">
		
		
		
		
	</head>
	<body>
	<!-- Tabs -->
	<h2>User Registration</h2>
		<form id="regform">
			<fieldset>
				
				<!-- Autocomplete First Names -->
				<label for="fname"> First Name:</label>
				<input type="text" id="fname" placeholder="Enter Name" name="name" title="type &quot;a&quot;" required autofocus><br><br>
				
				<label for="lname"> Last Name:</label>
				<input type="text" id="lname" placeholder="Enter Name" name="name" required><br><br>
				
				<!--Email-->
				<label for="email">Email:</label>
				<input type="email" id="email" placeholder="Enter Email" name="email" required><br><br>
				
				<!--Birthday-->
				<label for="bday">Birthday Day:</label>
				<input type="text" id="bday" placeholder="Enter Birthday"><br><br>
				
				<!--Telephone-->
				<label for="tele">Phone Number:</label>
				<input type="tel" id="tele" placeholder="(317) 444 6954" name="tele" required><br><br>
				
				<!--Password-->
				<label for="password">Password:</label>
				<input type="password" id="password" placeholder="Enter Password" name="password" required><br><br>
				
				<!--Password-->
				<label for="passwordconfirm">Confirm Password:</label>
				<input type="password" id="passwordconfirm" placeholder="Enter Password" name="passwordconfirm" required><br><br>
				
				<!--Menu selection-->
				<label for="meal">Selection:</label>
				<select id="meal" name="meal">
					<option>House Salad</option>
					<option>French Onion Soup</option>
					<option selected="selected">Mediterranean Shrimp Naan</option>
				</select><br><br>
				
				<!-- Checkboxradio -->
				<label for="mealsize">Gender</label>
				<div id="mealsize">
					<input type="radio" id="small" name="radio" value="Male"><label for="radio1">Male(M)</label><br>
					<input type="radio" id="medium" name="radio" value="Female" checked="checked"><label for="radio2">Female(F)</label><br>
					<input type="radio" id="large" name="radio" value="Other"><label for="radio3">Other(O)</label><br>
				</div><br><br>
				
				
				<label for="sauce">Status</label><br>
				   <input id ="bbq" name="sauce" type="checkbox" value="Barbeque" class ="saucey">BBQ <br>
                   <input id ="hm" name="sauce" type="checkbox" value="Honey Mustard" class ="saucey">Honey Mustard &nbsp;
				   <input id ="ranch" name="sauce" type="checkbox" value="Buttermilk Ranch" class ="saucey">Ranch <br>
                   <input id ="sir" name="sauce" type="checkbox" value="Sriracha" class ="saucey">Sriracha &nbsp;
				   <input id ="ket" name="sauce" type="checkbox" value="Ketchup" class ="saucey" checked="checked">Ketchup <br><br>
			
		
				<!-- Spinner -->
				<label for="spinner">Quantity:</label>
				<input  min= "1" max="10" id="spinner" name="spinner" value="1" onkeydown="return false"><br><br>
			
				<!-- Submit & Clear Button -->
				<button type="submit" id="submit">Submit</button>
				<button type="reset" id="clear">Reset</button>
				
			</fieldset>
		</form>
		<fieldset>
			<h2>Output:</h2>
			<p id="textchange"></p>
		</fieldset>
		
		
		
		<!-- Link to jQuery Library -->
		<script src="theme/external/jquery/jquery.js"></script>
		 
		
		<!-- jQuery UI functionality -->
		<script type="text/javascript" src="theme/jquery-ui.js"></script>
		
		<!-- Link to jQuery Validator -->
		<script type="text/javascript" src="validation/dist/jquery.validate.js"></script>
		
		<!-- Link to javascript of functionality -->
		<script type="text/javascript" src="js/Form.js"></script>
		
		
	</body>
</html>