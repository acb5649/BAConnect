<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- 
Jonathan Young
09/07/18
process.php
-->
<html lang="EN" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>Account Creation Successful!</title>
	<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="css/mySTYLE.css">
	<style type = "text/css">
  		h1 {
			color: #4CAF50;
    		text-align: center;
		}
		h2, fieldset {
			color: #4CAF50;
    		text-align: left;
			font-weight: bold;
  		}
		.btn {
			border-radius: 4px;
			background-color: white; 
			color: #4CAF50; 
			border: 2px solid #4CAF50;
		}
		.btn:hover {
			background-color: #4CAF50;
			color: white;
		}
	</style>

	</head>

	<body>

		<?php
			$fn = "";
			$ln = "";
			$deliver = "";
			$gender = "";
			$depart = "";
			$status = "";
			$em = "";
			$pass = "";
			
			$fn = $_GET['fn'];
			$ln = $_GET['ln'];
			$em = $_GET['em'];
			$pass = $_GET['p'];
			$gender = $_GET['g'];
			$depart = $_GET['d'];
			$status = $_GET['s'];
			$deliver = $_GET['de'];

		?>
		<h1 style="font-family: 'Anton' , sans-serif;">User Registration Confirmation</h1>
			<?php
				print $deliver;
				$deliver = "";
			?>
		
		<fieldset>

			First Name: <?php print $fn; ?> <br />	
			Last Name: <?php print $ln; ?> <br />
			Email:	<?php print $em; ?> <br />
			Gender: <?php print $gender; ?> <br />
			Department: <?php print $depart; ?> <br />
			Status: <?php print $status; ?> <br />
		</fieldset>
			
					</form>



	</body>
</html>


