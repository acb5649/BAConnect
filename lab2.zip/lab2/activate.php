<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- 
Jonathan Young
activate.php
-->
<html lang="EN" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title> Email Activation</title>
	<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="css/mySTYLE.css">
	<style type = "text/css">
  		h1 {
			color: #4CAF50;
    		text-align: center;
		}
		h2, fieldset {
			color: #4CAF50;
    		text-align: center;
			font-weight: bold;
  		}
		.btn {
			border-radius: 4px;
			background-color: white; 
			color: #4CAF50; 
			border: 2px solid #4CAF50;
		}
		.btn:hover {
			background-color: #4CAF50;
			color: white;
		}
	</style>

	</head>

	<body>

		<?php
			$em = "";
			$code = "";
			$stat = "";
			$msg = "";
			$code = $_GET['a'];
			$em = $_GET['em'];
			$success = false;
			$seconds = "5";
			$location = "login.php";
			
			
			//check code
			if (strlen($code) < 30){
				 $stat = '<span style="color:red">FAILURE</span>';
			}else {
				//go through each character and find if there is a number or letter
				$letter = false;
				$number = false;
				$chars = str_split($code);
				for($i = 0; $i<strlen($code); $i++){
					if (preg_match("/[A-Za-z]/",$chars[$i])){
						$letter = true;
						break;
					}
				}
				for($i = 0; $i<strlen($code); $i++){
					if (preg_match("/[0-9]/",$chars[$i])){
						$number = true;
						break;
					}
				}
				if (($letter == true) and ($number == true)){
					$success= true;
					$stat ='<span style="color:blue">SUCCESS</span>';
				}else{ 
					$stat = '<span style="color:red">FAILURE</span>';
				}
			}
			//redirect to login page only if email is activated
			if($success){
				$msg = "<b>Redirecting to login...</b>";
				header("Refresh: $seconds; URL=\"$location\"");	
					
			}

		?>
		<h1>Email Activation</h1>
		
		<fieldset>
			Email:	<?php print $em; ?> <br />
			Activation: <?php print $stat; ?> <br /><br/>
			
			<?php
				print $msg;
				$msg = "";
			?>
		</fieldset>
	
					</form>



	</body>
</html>