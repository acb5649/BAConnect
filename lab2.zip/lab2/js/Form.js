
$(document).ready(function() {
	

	//suggest names list
	$.getJSON("json/first-names.json", function (fName) {
	  $( "#fname" ).autocomplete({
			source: fName,
			minLength: 2
		})
	});
	
	//UI Library autocomplete name fucntion
	
	

	$.validator.setDefaults({
		submitHandler: function() {
			// Scrape Data
			var strFname = $("#fname").val();				// first name
			var strLname = $("#Lname").val();			// last name
			var strMeal = $("#meal option:selected").text();			// meal
			var strQuantity = $("#spinner").val();			// quantity
			var strEmail = $("#email").val(); //email
			var strPassword = $("#password").val(); //pass
			var strConfirmPassword = $("#confirmpassword").val();//passconfirm
			var strTele = $("#tele").val();//telephone
			var strSize = $('input[name="radio"]:checked').val(); //mealsize
			var strSauce = "";
			$('input[name="sauce"]:checked').each(function() {		// List checked sauces
					strSauce += $(this).val() + " ";
			});
			// Send all data to output area
			$('#textchange').append("<br><br> First Name: " + strFname)
							.append("<br><br> Last Name: " + strLname)
							.append("<br><br> Email: " + strEmail)
							.append("<br><br> Tele: " + strTele)
							.append("<br><br> Birthday: " + strBday)
							.append("<br><br> Password: " + strPassword)
							.append("<br><br> Meal: " + strMeal)
							.append("<br><br> Size: " + strSize)
							.append("<br><br> Quantity: " + strQuantity)
							.append("<br><br> Sauace(s): " + strSauce)
							.append("<br><br><br>")
			
			alert("You're Registration was Successful!");
			} // end submitHandler
	}); // end validator.setDefaults
	$("#orderform").validate({       
			rules: {
				name: {							//<input name="name">
					required: true,
					maxlength: 8
				},
				password: {							//<input name="password">
					required: true,
					minlength: 6,
					maxlength: 10
				},
				passwordconfirm: {					//<input name="passwordconfirm">
					required: true,
					equalTo: "#password"
				},
				bday: {								//<input name="bday">
					required: true,
					date: true
				},
				tele: {							//<input name="tele">
					required: true,
					digits: true,
					maxlength: 10
				},
				email: {							//<input name="email">
					required: true,
					email: true
				},
				sauce: {							//<input name="sauce">
					required: true
				}
			}, // end rules
			messages: {                             // These messages are displayed when user input doesn't match the rules
				name: {							//<input name="name">
					required: "Please enter a name",
					maxlength: $.validator.format("Must not have more than {0} characters")
				},
				password: {							//<input name="password">
					required: "Please provide a password",
					minlength: $.validator.format("Must have at least {0} characters")
				},
				passwordconfirm: {					//<input name="passwordconfirm">
					required: "Please confirm the password",
					equalTo: "Passwords must match."
				},
				bday: {								//<input name="bday">
					required: "Please enter a birthday date",
					date: "Please enter a valid date"
				},
				tele: {							//<input name="tele">
					required: "Please enter a phone number",
					digits: "Please enter  valid digits only",
					maxlength: 10
				},
				email: {							//<input name="email">
					required: "Please enter an email address",
					email: "Please enter a valid email address"
				},
				sauce: {							//<input name="sauce">
					required: " (Please select at least one sauce) "
				}
			}  // end messages
		});
	//UI Library tab menu function
	$( "#tabs" ).tabs();
	//UI Library spiner quantity function
	$( "#spinner" ).spinner();
	//UI Library datepicker birthday function
	$( "#bday" ).datepicker({
	inline: true
	});
	
	//buttons submits data and clears
	$( "#submit" ).button();		
	$( "#clear" ).button();
	$( "mealsize" ).buttonset();

	
});


