<?php 
	require_once "inc/util.php";
	require_once "mail/mail.class.php";

	$msg = "";
	$term = "You must agree to the terms and conditions";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Jonathan Young
09/07/18
lab1.php
-->
<html lang="EN" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>User Registration</title>
	<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="css/mySTYLE.css">
	<style type = "text/css">
  		h1 {
			color: #4CAF50;
    		text-align: center;
		}
		h2, fieldset {
			color: #4CAF50;
    		text-align: left;
			font-weight: bold;
  		}
		.btn {
			border-radius: 4px;
			background-color: white; 
			color: #4CAF50; 
			border: 2px solid #4CAF50;
			font-size: 16px;
		}
		.btn:hover {
			background-color: #4CAF50;
			color: white;
		}
	</style>

	</head>

	<body>

		<?php
			//always initialize variables to be used
			$fn = "";
			$ln = "";
			$em = "";
			$emc = "";
			$pass = "";
			$passc = "";
			$gender = "";
			$depart = "";
			$status = "";
			$agree = "";
			$msg = "";
			$deliver="";
			$fnre="*";
			$lnre="*";
			$emre="*";
			$passre="*";
			$matche ="*";
			$matchp ="*";
			$maleChecked = "checked";
			$femaleChecked = "";
			$studentChecked = "";
			$facultyChecked = "";
			$staffChecked = "";
			
			$emailok = false;
			$pwdok = false;
			$agreeok = false;
			
			

			if (isset($_POST['enter'])) //check if this page is requested after Submit button is clicked
			{
				
			
				$fn = trim($_POST['firstName']);
				$ln = trim($_POST['lastName']);
				$pass = trim($_POST['password']);
				$passc = trim($_POST['passwordcon']);
				
				if (!pwdValidate($pass)){
					$msg = $msg . '<br/><b>Password is not in the required format.</b>';
					
				}else {
					//confirm password match
					if ($pass != $passc){
						$msg = $msg . '<br/><b>Passwords are not the same.</b>';
						$pass = "";
						$passc = "";
						$passre = '<span style="color:red">*</span>';
						$matchp = '<span style="color:red">*</span>';
					}else{ 
						$pwdok = true;
					}
				}
				
				//confirm password match
				
				//validate email
				if (!filter_input(INPUT_POST, 'email',FILTER_VALIDATE_EMAIL)){
					$emre = '<span style="color:red">*</span>';
				}else{
					$em = trim($_POST['emailcon']);
					if (!spamcheck($em)){							
						$msg = $msg . '<br/><b>Email is not valid.</b>';
					}else{
						$emailok = true;
						$emc = trim($_POST['emailcon']);
					}
				}
				//check if emails match
				if ($em != $emc) {
					$em = "";
					$emc = "";
					$emre = '<span style="color:red">*</span>';
					$matche = '<span style="color:red">*</span>';
				}
				//gender
				if (isset($_POST['gender'])){
					$gender = trim($_POST['gender']);
		
				}
				if ($gender=="Male") {
					$maleChecked="checked";
					$femaleChecked="";
				} else {
					$maleChecked="";
					$femaleChecked="checked";
				}
				//status
				if (isset($_POST['status'])){
					$status = trim($_POST['status']);
					
				}
				if ($status=="Student"){
					$studentChecked="checked";
					$facultyChecked="";
					$staffChecked="";
				}elseif ($status=="Faculty"){
					$studentChecked="";
					$facultyChecked="checked";
					$staffChecked="";
				}elseif ($status=="Staff") {
					$studentChecked="";
					$facultyChecked="";
					$staffChecked="checked";
				}else {
					$status = "Empty";
				}
				//department
				$depart = trim($_POST['depart']);
				//accept
				if (!isset($_POST['agree'])) {
					$msg = $msg .  "<br/><b> You must agree to the terms and conditions </b><br />";
					$term = '<span style="color:red">You must agree to the terms and conditions</span>';

				}else{ 
					$agreeok = true;
				}
				
				if ($fn== ""){
					$fnre = "<span style=\"color:red\">*</span>";
				}
				if ($ln== ""){
					$lnre = '<span style="color:red">*</span>';
				}
				if ($pass== ""){
					$passre = '<span style="color:red">*</span>';
				}
				if (($fnre!="*") || ($lnre != "*") || ($emre != "*") || ($passre != "*"))				
				{	
					if(($matche!="*")){
						//emails don't match
						$msg = "<br /><span style=\"color:red\">Emails did not match!</span><br />";
					}elseif(($matchp!="*")){
						//passwords don't match
						$msg = "<br /><span style=\"color:red\">Passwords did not match!</span><br />";
					}else{
						//blanbk entry
						$msg = "<br /><span style=\"color:red\">Please enter valid data!</span><br />";
					}
				}
				elseif ($emailok && $pwdok && $agreeok) {
					//you will enter data into the database here

					//now send the email to the username registered for activating the account
					$code = randomCodeGenerator(50);
					$subject = "Email Verification";
										
					$body = 'Thank you for registering, '.$fn.' '.$ln.'! <br/> Please click on this url to activate your account. <br/>
					
						 http://corsair.cs.iupui.edu:23251/lab1/activate.php?a='.$code.'&em='.$em;
					$mailer = new Mail();
					if (($mailer->sendMail($em, $fn, $subject, $body))==true){
						$deliver = "<span style=\'color:green\">A activation message has been sent to the address you have just registered.</span>";
						Header ("Location:process.php?fn=".$fn."&ln=".$ln."&em=".$em."&g=".$gender."&d=".$depart."&p=".$pass."&s=".$status."&de=".$deliver) ;
					}else{
						$msg = " Account Creation Failure: Email not sent. " . $em.' '. $fn.' '. $subject.' '. $body;
					}		
				}
			}
		?>

		<form action="lab2.php" method="post">
			<h1 style="font-family: 'Anton' , sans-serif;">User Registration</h1>
			<?php
				print $msg;
				$msg = "";
			?>
			<fieldset>
				First Name: <?php print $fnre; ?>
					<input type="text" maxlength = "50" value="<?php print $fn; ?>" name="firstName" id="firstName"  placeholder="First Name" required autofocus /> <br /><br />
				Last Name: <?php print $lnre; ?>
					<input type="text" maxlength = "50" value="<?php print $ln; ?>" name="lastName" id="lastName"  placeholder="Last Name" required />  <br /><br />
				Email: <?php print $emre; ?>
					<input type="email" maxlength = "50" value="<?php print $em; ?>" name="email" id="email" required  />  <br /><br />
				Confirm Email: <?php print $matche; ?>
					<input type="email" maxlength = "50" value="<?php print $emc; ?>" name="emailcon" id="emailcon"   />  <br /><br/>
				Password: <?php print $passre; ?>
					<input type="password" maxlength = "50" value="<?php print $pass; ?>" name="password" id="password" required  />  <br /><br />
				Confirm Password: <?php print $matchp; ?>
					<input type="password" maxlength = "50" value="<?php print $passc; ?>" name="passwordcon" id="passwordcon" required  />  <br /><br />
				Gender: 
					<input type = "radio" name = "gender" value = "Male" <?php print $maleChecked; ?> />Male
					<input type = "radio" name = "gender" value = "Female" <?php print $femaleChecked; ?> />Female <br /><br/>
				Department:
				<select  name = "depart">
					<option value = "Science">Science</option>
					<option value = "Mathematics" selected>Mathematics</option>
					<option value = "Engineering">Engineering</option>
					<option value = "Liberal Arts">Liberal Arts</option>
					<option value = "Education">Education</option>
				</select><br/><br />
				Status:
				<input name = "status" type= "checkbox" value = "Student" <?php print $studentChecked; ?> />Student
				<input name = "status" type= "checkbox" value = "Faculty" <?php print $facultyChecked; ?> />Faculty
				<input name = "status" type= "checkbox" value = "Staff" <?php print $staffChecked; ?> />Staff <br /><br />
				
				<fieldset>
					<input type="checkbox" name = "agree" value="y" /> 
					<?php print $term; ?>
					<br />
				</fieldset>
				<br/>
				<input name="enter" class="btn" type="submit" value="Submit" />
			</fieldset>
		</form>



	</body>
</html>


